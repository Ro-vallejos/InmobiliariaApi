Integrantes : Roberta Vallejos y Valentin Gimenez

admin: admin@gmail.com 123

empleado: empleado@gmail.com 123

"Mysql": "Server=localhost;Database=inmobiliaria;User=root;Password=;"
